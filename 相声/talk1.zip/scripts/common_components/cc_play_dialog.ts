/**!
 * @description 点数累加展示
 * @see https://bytedance.feishu.cn/wiki/wikcnyHxiKLJde7hXHtfQ2enphi#
 */
const { ccclass, requireComponent } = cc._decorator;

@ccclass
@requireComponent(sp.Skeleton)
export default class CCPlayDialog extends cc.Component {
  // LIFE-CYCLE CALLBACKS:

  // onLoad() {
  // }
  start() {
    const spine = this.getComponent(sp.Skeleton);
    if (spine) {
      spine.setEventListener((animation, event) => {
        const name = event.data.name;
        const clipNode = this.node.getChildByName(name);
        if (clipNode) {
          clipNode.getComponent(cc.AudioSource).play();
        } else {
          console.error(`请检查一下文件的音频[${name}]的子节点是否存在`);
        }
      });
      cc.director.emit('AnimationPlay');
      spine.setCompleteListener(() => {
        cc.director.emit('AnimationStop');
      });
      spine.setAnimation(0, spine.defaultAnimation, false);
    }
  }
}

/**!
 * @description 组合识别（Combine）模版
 * @see https://bytedance.feishu.cn/wiki/wikcnPronp3nS0O2XhbfERH1xCh
 */
import Core_AbstractTemplateController from '../common_components/core_templateController';
import { InGameEvents } from '../common_components/core_consts';

const { ccclass, property } = cc._decorator;

@ccclass
export default class EmptyController extends Core_AbstractTemplateController {
  @property({
    type: cc.Boolean,
    displayName: '开启组件Debug模式',
    tooltip: '开启Debug模式，会在Console中输出一些信息，辅助你Debug当前的开发问题',
  })
  isDebug = false;

  public onGGLGameInit(config: Section): void {
    // placeholder
    gameEvent.emit('transitionStart');

    cc.director.once(InGameEvents.ShowQuestionFinish, () => {
      gameEvent.emit('transitionEnd');
    });
  }
  public onGGLGameClear(): void {
    // Placeholder
  }
}
